# UltimateBraveryBatch

Ultimate Bravery is a fanmade gamemode in League of Legends where most aspects of the game are randomized.

Features:

- [X] Summoner's Rift Bravery
- [X] Twisted Treeline Bravery
- [X] Howling Abyss Bravery
- [X] Custom Champion Selection
- [X] Settings Menu
- [X] Last build saving
- [X] Update Check

---
Tyler Gibbs
